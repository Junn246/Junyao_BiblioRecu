﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BiblioRecu
{
    public class ClBiblio
    {
        private Hashtable taulaH = new Hashtable();

        public void taulaHashRepetida(string v, List<string> llwords)
        {
            foreach (string word in v.Split(' '))
            {
                if (taulaH.ContainsKey(word.Trim()))
                {
                    taulaH[word.Trim()] = ((Int32)taulaH[word.Trim()]) + 1;
                }
                else
                {
                    taulaH.Add(word.Trim(), null);
                    taulaH[word.Trim()] = 0;
                    llwords.Add(word.Trim());
                }
            }
        }
        public int QuantesVocals(String xs)
        {
            String vocals = "AEIOUÀÁÈÉÍÏÓÒÚÜ";
            int i = 0;
            int n = 0;

            for (i = 0; i < xs.Length; i++)
            {
                if (vocals.Contains(xs.Substring(i, 1).ToUpper()))
                {
                    n++;
                }
            }
            return (n);
        }
        public List<string> MesRepetides(string v1, string v2)
        {
            taulaH.Clear();
            List<string> llwords = new List<string>();
            List<string> result = new List<string>();
            taulaHashRepetida(v1, llwords);
            taulaHashRepetida(v2, llwords);

            ArrayList aKeys = new ArrayList(taulaH.Keys);
            aKeys.Sort();
            foreach (string key in aKeys)
                result.Add(key.ToString());

            return result;
        }
        public String ElMeuEncode(String xs, Int32 n)
        {
            String resultat = "";

            string invertirString = string.Empty;
            foreach (char c in xs)
            {
                invertirString = c + invertirString;
            }

            foreach (char c in invertirString)
            {
                int unicode = c;
                string anadeCeros = "";

                switch (n - unicode.ToString().Length)
                {
                    case 0: anadeCeros = ""; break;
                    case 1: anadeCeros = "0"; break;
                    case 2: anadeCeros = "00"; break;
                    case 3: anadeCeros = "000"; break;
                    case 4: anadeCeros = "0000"; break;
                    case 5: anadeCeros = "00000"; break;
                    case 6: anadeCeros = "000000"; break;
                }

                resultat = resultat + anadeCeros + unicode;
            }

            return resultat;
        }

        public String ElMeuDecode(String xs, Int32 n)
        {
            String resultat = "";
            String letra = "";

            List<String> list = new List<String>();

            for (int i = 0; i < xs.Length; i++) // Separamos cada letra de la string segun n caracteres
            {
                letra = letra + xs[i];

                if (letra.Length == n)
                {
                    list.Add(letra);
                    letra = "";
                }
            }

            foreach (var lletra in list)
            {
                int unicode = Convert.ToInt32(lletra);
                char character = (char)unicode;
                string text = character.ToString();

                resultat = resultat + text;
            }

            char[] myArr = resultat.ToCharArray();
            Array.Reverse(myArr);
            resultat = new string(myArr);

            return resultat;
        }
    }
}
