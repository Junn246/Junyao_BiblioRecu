﻿using BiblioRecu;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace ProvaUnit
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void QuantesVocals()
        {
            int resultat;
            String cadena = "holà tonto";
            int numV = 4;

            ClBiblio kal = new ClBiblio();
            resultat = kal.QuantesVocals(cadena);
            Assert.AreEqual(numV, resultat);
            Console.WriteLine("resultat: " + resultat);
        }

        [TestMethod]
        public void ordenarParaulesRepetides()
        {

            string h1 = "hola a todos";
            string h2 = "hola a ti";

            List<string> resultat1 = new List<string>();
            resultat1.Clear();
            resultat1.AddRange(new[] { "a", "hola", "ti", "todos" });

            List<string> resultat2 = new List<string>();

            ClBiblio kal = new ClBiblio();
            resultat2 = kal.MesRepetides(h1, h2);
            CollectionAssert.AreEqual(resultat1, resultat2);

            foreach (string vw in resultat2)
            {
                Console.WriteLine("resultat: " + vw);
            }

        }

        [TestMethod]
        public void ElMeuEncode()
        {
            ClBiblio cripto = new ClBiblio();

            String paraula = "HOLA";
            String comprobacio = "065076079072";

            String resultat = cripto.ElMeuEncode(paraula, 3);
            Assert.AreEqual(comprobacio, resultat);
            Console.WriteLine("Comprovacio: " + comprobacio + " Res: " + resultat);
        }

        [TestMethod]
        public void ElMeuDecode()
        {
            ClBiblio cripto = new ClBiblio();

            String paraula = "065076079072";
            String comprobacio = "HOLA";

            String resultat = cripto.ElMeuDecode(paraula, 3);
            Assert.AreEqual(comprobacio, resultat);
            Console.WriteLine("Comprovacio: " + comprobacio + " Res: " + resultat);
        }
    }
}
